import { useState, useEffect } from "react";
import { SearchFilters } from "@/components/SearchFilters";
import { EntriesTable } from "@/components/EntriesTable";
import { EntryDetailsDrawer } from "@/components/EntryDetailsDrawer";
import { PaginationControls } from "@/components/PaginationControls";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AlertCircle, RefreshCw, LogOut } from "lucide-react";
import { Button } from "@/components/ui/button";
import { fetchWPFormsEntries } from "@/lib/wpforms-api";
import type { WPFormEntry, WPFormsEntriesResponse } from "@/types/wpforms";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/contexts/AuthContext";
import jaipuriaLogo from "@/assets/jaipuria-logo.png";

export default function Dashboard() {
  const [entries, setEntries] = useState<WPFormEntry[]>([]);
  const [selectedEntry, setSelectedEntry] = useState<WPFormEntry | null>(null);
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Filter states
  const [search, setSearch] = useState("");
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");

  // Pagination states
  const [currentPage, setCurrentPage] = useState(1);
  const [perPage, setPerPage] = useState(20);
  const [totalPages, setTotalPages] = useState(1);
  const [totalItems, setTotalItems] = useState(0);

  const { toast } = useToast();
  const { logout } = useAuth();

  const loadEntries = async () => {
    setIsLoading(true);
    setError(null);

    try {
      const response: WPFormsEntriesResponse = await fetchWPFormsEntries({
        formId: import.meta.env.VITE_WPFORMS_FORM_ID || "1234",
        page: currentPage,
        perPage,
        search,
        dateFrom,
        dateTo,
      });

      setEntries(response.entries);
      setTotalItems(response.pagination.total);
      setTotalPages(Math.ceil(response.pagination.total / perPage));
    } catch (err) {
      console.error("Error loading entries:", err);
      setError(
        err instanceof Error 
          ? err.message 
          : "Failed to load form submissions. Please check your configuration."
      );
      toast({
        title: "Error",
        description: "Failed to load submissions. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadEntries();
  }, [currentPage, perPage, search, dateFrom, dateTo]);

  const handleViewEntry = (entry: WPFormEntry) => {
    setSelectedEntry(entry);
    setIsDrawerOpen(true);
  };

  const handleCloseDrawer = () => {
    setIsDrawerOpen(false);
    setTimeout(() => setSelectedEntry(null), 300);
  };

  const handleClearFilters = () => {
    setSearch("");
    setDateFrom("");
    setDateTo("");
    setCurrentPage(1);
  };

  const handlePageChange = (page: number) => {
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handlePerPageChange = (newPerPage: number) => {
    setPerPage(newPerPage);
    setCurrentPage(1);
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* Header */}
      <header className="sticky top-0 z-10 border-b bg-background shadow-sm">
        <div className="flex h-20 items-center gap-4 px-6">
          <div className="flex items-center gap-4">
            <img 
              src={jaipuriaLogo} 
              alt="Jaipuria Institute of Management" 
              className="h-12 w-auto"
            />
            <div className="h-10 w-px bg-border" />
            <div>
              <h1 className="text-base font-semibold text-foreground">
                Forms Dashboard
              </h1>
              <p className="text-xs text-muted-foreground">
                Student Submission Manager
              </p>
            </div>
          </div>
          <div className="flex-1" />
          <Button
            variant="ghost"
            size="sm"
            onClick={logout}
            className="gap-2 text-muted-foreground hover:text-destructive"
          >
            <LogOut className="h-4 w-4" />
            Logout
          </Button>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 p-6 space-y-6 max-w-7xl mx-auto w-full">
        <div>
          <h2 className="text-2xl font-bold mb-2">Form Submissions</h2>
          <p className="text-muted-foreground">
            View and manage student document submissions
          </p>
        </div>

        <SearchFilters
          search={search}
          onSearchChange={setSearch}
          dateFrom={dateFrom}
          onDateFromChange={setDateFrom}
          dateTo={dateTo}
          onDateToChange={setDateTo}
          onClearFilters={handleClearFilters}
        />

        {error && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription className="flex items-center justify-between">
              <span>{error}</span>
              <Button
                variant="outline"
                size="sm"
                onClick={loadEntries}
                className="ml-4"
              >
                <RefreshCw className="h-4 w-4 mr-2" />
                Retry
              </Button>
            </AlertDescription>
          </Alert>
        )}

        <EntriesTable
          entries={entries}
          onViewEntry={handleViewEntry}
          isLoading={isLoading}
        />

        {!isLoading && entries.length > 0 && (
          <PaginationControls
            currentPage={currentPage}
            totalPages={totalPages}
            perPage={perPage}
            totalItems={totalItems}
            onPageChange={handlePageChange}
            onPerPageChange={handlePerPageChange}
          />
        )}
      </main>

      <EntryDetailsDrawer
        entry={selectedEntry}
        open={isDrawerOpen}
        onClose={handleCloseDrawer}
      />
    </div>
  );
}

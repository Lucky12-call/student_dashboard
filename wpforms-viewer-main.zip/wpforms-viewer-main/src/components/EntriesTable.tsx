import { useState } from "react";
import { Eye, FileText, Calendar } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import type { WPFormEntry } from "@/types/wpforms";
import { format } from "date-fns";

interface EntriesTableProps {
  entries: WPFormEntry[];
  onViewEntry: (entry: WPFormEntry) => void;
  isLoading?: boolean;
}

export function EntriesTable({ entries, onViewEntry, isLoading }: EntriesTableProps) {
  if (isLoading) {
    return (
      <div className="border rounded-lg p-8">
        <div className="flex items-center justify-center">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
            <p className="text-muted-foreground">Loading entries...</p>
          </div>
        </div>
      </div>
    );
  }

  if (entries.length === 0) {
    return (
      <div className="border rounded-lg p-8">
        <div className="text-center">
          <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
          <h3 className="text-lg font-semibold mb-2">No submissions found</h3>
          <p className="text-muted-foreground">
            Try adjusting your search filters or date range.
          </p>
        </div>
      </div>
    );
  }

  const getFieldValue = (entry: WPFormEntry, fieldKey: string): string => {
    const field = entry.fields[fieldKey];
    return field?.value || "N/A";
  };

  const countFileFields = (entry: WPFormEntry): number => {
    return Object.values(entry.fields).filter((field) => field.type === "file" && field.value).length;
  };

  return (
    <div className="border rounded-lg overflow-hidden">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Date</TableHead>
            <TableHead>Student Name</TableHead>
            <TableHead>Email</TableHead>
            <TableHead>Course</TableHead>
            <TableHead className="text-center">Documents</TableHead>
            <TableHead>Status</TableHead>
            <TableHead className="text-right">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {entries.map((entry) => {
            const documentCount = countFileFields(entry);
            const studentName = getFieldValue(entry, "student_name");
            const email = getFieldValue(entry, "email");
            const course = getFieldValue(entry, "course");

            return (
              <TableRow key={entry.entry_id}>
                <TableCell>
                  <div className="flex items-center gap-2 text-sm">
                    <Calendar className="h-4 w-4 text-muted-foreground" />
                    {format(new Date(entry.date), "MMM dd, yyyy")}
                  </div>
                  <div className="text-xs text-muted-foreground mt-1">
                    {format(new Date(entry.date), "hh:mm a")}
                  </div>
                </TableCell>
                <TableCell className="font-medium">{studentName}</TableCell>
                <TableCell>{email}</TableCell>
                <TableCell>{course}</TableCell>
                <TableCell className="text-center">
                  <Badge variant={documentCount > 0 ? "default" : "secondary"}>
                    {documentCount} {documentCount === 1 ? "file" : "files"}
                  </Badge>
                </TableCell>
                <TableCell>
                  <Badge
                    variant={entry.status === "read" ? "secondary" : "default"}
                  >
                    {entry.status}
                  </Badge>
                </TableCell>
                <TableCell className="text-right">
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => onViewEntry(entry)}
                    className="gap-2"
                  >
                    <Eye className="h-4 w-4" />
                    View
                  </Button>
                </TableCell>
              </TableRow>
            );
          })}
        </TableBody>
      </Table>
    </div>
  );
}

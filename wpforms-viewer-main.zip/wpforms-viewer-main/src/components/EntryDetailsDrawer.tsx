import { Download, Mail, Calendar, FileText, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
} from "@/components/ui/sheet";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import type { WPFormEntry, WPFormFieldValue } from "@/types/wpforms";
import { format } from "date-fns";

interface EntryDetailsDrawerProps {
  entry: WPFormEntry | null;
  open: boolean;
  onClose: () => void;
}

export function EntryDetailsDrawer({ entry, open, onClose }: EntryDetailsDrawerProps) {
  if (!entry) return null;

  const handleDownload = (url: string, label: string) => {
    window.open(url, "_blank", "noopener,noreferrer");
  };

  const renderFieldValue = (field: WPFormFieldValue, fieldKey: string) => {
    switch (field.type) {
      case "file":
        if (!field.value) return <span className="text-muted-foreground">No file uploaded</span>;
        
        // Handle multiple files separated by comma
        const files = field.value.split(",").map((url) => url.trim()).filter(Boolean);
        
        return (
          <div className="space-y-2">
            {files.map((fileUrl, index) => {
              const fileName = fileUrl.split("/").pop() || `file-${index + 1}`;
              return (
                <Button
                  key={index}
                  variant="outline"
                  size="sm"
                  onClick={() => handleDownload(fileUrl, field.label)}
                  className="w-full justify-start gap-2"
                >
                  <Download className="h-4 w-4" />
                  <span className="truncate">{decodeURIComponent(fileName)}</span>
                </Button>
              );
            })}
          </div>
        );

      case "email":
        return (
          <a
            href={`mailto:${field.value}`}
            className="text-primary hover:underline flex items-center gap-2"
          >
            <Mail className="h-4 w-4" />
            {field.value}
          </a>
        );

      default:
        return <span>{field.value || "N/A"}</span>;
    }
  };

  const fileFields = Object.entries(entry.fields).filter(
    ([_, field]) => field.type === "file" && field.value
  );

  const nonFileFields = Object.entries(entry.fields).filter(
    ([_, field]) => field.type !== "file"
  );

  return (
    <Sheet open={open} onOpenChange={onClose}>
      <SheetContent className="sm:max-w-xl overflow-y-auto">
        <SheetHeader>
          <SheetTitle>Submission Details</SheetTitle>
          <SheetDescription>
            Entry ID: {entry.entry_id} | Form ID: {entry.form_id}
          </SheetDescription>
        </SheetHeader>

        <div className="mt-6 space-y-6">
          {/* Meta Information */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Calendar className="h-4 w-4" />
              {format(new Date(entry.date), "MMMM dd, yyyy 'at' hh:mm a")}
            </div>
            <Badge variant={entry.status === "read" ? "secondary" : "default"}>
              {entry.status}
            </Badge>
          </div>

          <Separator />

          {/* Documents Section */}
          {fileFields.length > 0 && (
            <>
              <div>
                <h3 className="text-sm font-semibold mb-3 flex items-center gap-2">
                  <FileText className="h-4 w-4" />
                  Uploaded Documents ({fileFields.length})
                </h3>
                <div className="space-y-3">
                  {fileFields.map(([key, field]) => (
                    <div key={key} className="bg-muted/50 p-3 rounded-lg">
                      <p className="text-sm font-medium mb-2">{field.label}</p>
                      {renderFieldValue(field, key)}
                    </div>
                  ))}
                </div>
              </div>
              <Separator />
            </>
          )}

          {/* Form Fields */}
          <div>
            <h3 className="text-sm font-semibold mb-3">Form Information</h3>
            <div className="space-y-4">
              {nonFileFields.map(([key, field]) => (
                <div key={key}>
                  <label className="text-sm font-medium text-muted-foreground block mb-1">
                    {field.label}
                  </label>
                  <div className="text-sm">{renderFieldValue(field, key)}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
}

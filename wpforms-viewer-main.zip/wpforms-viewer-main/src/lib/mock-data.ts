import type { WPFormsEntriesResponse } from "@/types/wpforms";

// Mock data for development and testing
export const mockEntries: WPFormsEntriesResponse = {
  entries: [
    {
      entry_id: 1001,
      form_id: 1234,
      date: "2025-11-15T10:30:00",
      status: "read",
      fields: {
        student_name: {
          label: "Student Name",
          value: "Rahul Sharma",
          type: "text"
        },
        email: {
          label: "Email",
          value: "rahul.sharma@student.jaipuria.ac.in",
          type: "email"
        },
        course: {
          label: "Course",
          value: "PGDM 2026",
          type: "text"
        },
        phone: {
          label: "Phone Number",
          value: "+91 98765 43210",
          type: "text"
        },
        document_1: {
          label: "Marksheet",
          value: "https://online.jaipuria.ac.in/uploads/rahul_marksheet.pdf",
          type: "file"
        },
        document_2: {
          label: "ID Proof",
          value: "https://online.jaipuria.ac.in/uploads/rahul_id.pdf",
          type: "file"
        }
      }
    },
    {
      entry_id: 1002,
      form_id: 1234,
      date: "2025-11-15T09:15:00",
      status: "unread",
      fields: {
        student_name: {
          label: "Student Name",
          value: "Priya Verma",
          type: "text"
        },
        email: {
          label: "Email",
          value: "priya.verma@student.jaipuria.ac.in",
          type: "email"
        },
        course: {
          label: "Course",
          value: "MBA 2025",
          type: "text"
        },
        phone: {
          label: "Phone Number",
          value: "+91 98765 43211",
          type: "text"
        },
        document_1: {
          label: "Marksheet",
          value: "https://online.jaipuria.ac.in/uploads/priya_marksheet.pdf",
          type: "file"
        },
        document_2: {
          label: "ID Proof",
          value: "https://online.jaipuria.ac.in/uploads/priya_id.pdf",
          type: "file"
        },
        document_3: {
          label: "Experience Certificate",
          value: "https://online.jaipuria.ac.in/uploads/priya_experience.pdf",
          type: "file"
        }
      }
    },
    {
      entry_id: 1003,
      form_id: 1234,
      date: "2025-11-14T16:45:00",
      status: "read",
      fields: {
        student_name: {
          label: "Student Name",
          value: "Amit Kumar",
          type: "text"
        },
        email: {
          label: "Email",
          value: "amit.kumar@student.jaipuria.ac.in",
          type: "email"
        },
        course: {
          label: "Course",
          value: "PGDM 2026",
          type: "text"
        },
        phone: {
          label: "Phone Number",
          value: "+91 98765 43212",
          type: "text"
        },
        document_1: {
          label: "Marksheet",
          value: "https://online.jaipuria.ac.in/uploads/amit_marksheet.pdf",
          type: "file"
        }
      }
    },
    {
      entry_id: 1004,
      form_id: 1234,
      date: "2025-11-14T14:20:00",
      status: "read",
      fields: {
        student_name: {
          label: "Student Name",
          value: "Sneha Patel",
          type: "text"
        },
        email: {
          label: "Email",
          value: "sneha.patel@student.jaipuria.ac.in",
          type: "email"
        },
        course: {
          label: "Course",
          value: "MBA 2025",
          type: "text"
        },
        phone: {
          label: "Phone Number",
          value: "+91 98765 43213",
          type: "text"
        },
        document_1: {
          label: "Marksheet",
          value: "https://online.jaipuria.ac.in/uploads/sneha_marksheet.pdf",
          type: "file"
        },
        document_2: {
          label: "ID Proof",
          value: "https://online.jaipuria.ac.in/uploads/sneha_id.pdf",
          type: "file"
        }
      }
    },
    {
      entry_id: 1005,
      form_id: 1234,
      date: "2025-11-14T11:30:00",
      status: "unread",
      fields: {
        student_name: {
          label: "Student Name",
          value: "Vikram Singh",
          type: "text"
        },
        email: {
          label: "Email",
          value: "vikram.singh@student.jaipuria.ac.in",
          type: "email"
        },
        course: {
          label: "Course",
          value: "PGDM 2026",
          type: "text"
        },
        phone: {
          label: "Phone Number",
          value: "+91 98765 43214",
          type: "text"
        },
        document_1: {
          label: "Marksheet",
          value: "https://online.jaipuria.ac.in/uploads/vikram_marksheet.pdf",
          type: "file"
        },
        document_2: {
          label: "ID Proof",
          value: "https://online.jaipuria.ac.in/uploads/vikram_id.pdf",
          type: "file"
        },
        document_3: {
          label: "Photo",
          value: "https://online.jaipuria.ac.in/uploads/vikram_photo.jpg",
          type: "file"
        }
      }
    },
    {
      entry_id: 1006,
      form_id: 1234,
      date: "2025-11-13T15:50:00",
      status: "read",
      fields: {
        student_name: {
          label: "Student Name",
          value: "Ananya Reddy",
          type: "text"
        },
        email: {
          label: "Email",
          value: "ananya.reddy@student.jaipuria.ac.in",
          type: "email"
        },
        course: {
          label: "Course",
          value: "MBA 2025",
          type: "text"
        },
        phone: {
          label: "Phone Number",
          value: "+91 98765 43215",
          type: "text"
        },
        document_1: {
          label: "Marksheet",
          value: "https://online.jaipuria.ac.in/uploads/ananya_marksheet.pdf",
          type: "file"
        }
      }
    },
    {
      entry_id: 1007,
      form_id: 1234,
      date: "2025-11-13T13:25:00",
      status: "read",
      fields: {
        student_name: {
          label: "Student Name",
          value: "Karan Malhotra",
          type: "text"
        },
        email: {
          label: "Email",
          value: "karan.malhotra@student.jaipuria.ac.in",
          type: "email"
        },
        course: {
          label: "Course",
          value: "PGDM 2026",
          type: "text"
        },
        phone: {
          label: "Phone Number",
          value: "+91 98765 43216",
          type: "text"
        },
        document_1: {
          label: "Marksheet",
          value: "https://online.jaipuria.ac.in/uploads/karan_marksheet.pdf",
          type: "file"
        },
        document_2: {
          label: "ID Proof",
          value: "https://online.jaipuria.ac.in/uploads/karan_id.pdf",
          type: "file"
        }
      }
    },
    {
      entry_id: 1008,
      form_id: 1234,
      date: "2025-11-13T10:10:00",
      status: "unread",
      fields: {
        student_name: {
          label: "Student Name",
          value: "Neha Gupta",
          type: "text"
        },
        email: {
          label: "Email",
          value: "neha.gupta@student.jaipuria.ac.in",
          type: "email"
        },
        course: {
          label: "Course",
          value: "MBA 2025",
          type: "text"
        },
        phone: {
          label: "Phone Number",
          value: "+91 98765 43217",
          type: "text"
        },
        document_1: {
          label: "Marksheet",
          value: "https://online.jaipuria.ac.in/uploads/neha_marksheet.pdf",
          type: "file"
        },
        document_2: {
          label: "ID Proof",
          value: "https://online.jaipuria.ac.in/uploads/neha_id.pdf",
          type: "file"
        },
        document_3: {
          label: "Experience Certificate",
          value: "https://online.jaipuria.ac.in/uploads/neha_experience.pdf",
          type: "file"
        }
      }
    },
    {
      entry_id: 1009,
      form_id: 1234,
      date: "2025-11-12T17:30:00",
      status: "read",
      fields: {
        student_name: {
          label: "Student Name",
          value: "Rohan Desai",
          type: "text"
        },
        email: {
          label: "Email",
          value: "rohan.desai@student.jaipuria.ac.in",
          type: "email"
        },
        course: {
          label: "Course",
          value: "PGDM 2026",
          type: "text"
        },
        phone: {
          label: "Phone Number",
          value: "+91 98765 43218",
          type: "text"
        },
        document_1: {
          label: "Marksheet",
          value: "https://online.jaipuria.ac.in/uploads/rohan_marksheet.pdf",
          type: "file"
        }
      }
    },
    {
      entry_id: 1010,
      form_id: 1234,
      date: "2025-11-12T14:15:00",
      status: "read",
      fields: {
        student_name: {
          label: "Student Name",
          value: "Ishita Agarwal",
          type: "text"
        },
        email: {
          label: "Email",
          value: "ishita.agarwal@student.jaipuria.ac.in",
          type: "email"
        },
        course: {
          label: "Course",
          value: "MBA 2025",
          type: "text"
        },
        phone: {
          label: "Phone Number",
          value: "+91 98765 43219",
          type: "text"
        },
        document_1: {
          label: "Marksheet",
          value: "https://online.jaipuria.ac.in/uploads/ishita_marksheet.pdf",
          type: "file"
        },
        document_2: {
          label: "ID Proof",
          value: "https://online.jaipuria.ac.in/uploads/ishita_id.pdf",
          type: "file"
        }
      }
    },
    {
      entry_id: 1011,
      form_id: 1234,
      date: "2025-11-12T11:00:00",
      status: "unread",
      fields: {
        student_name: {
          label: "Student Name",
          value: "Arjun Khanna",
          type: "text"
        },
        email: {
          label: "Email",
          value: "arjun.khanna@student.jaipuria.ac.in",
          type: "email"
        },
        course: {
          label: "Course",
          value: "PGDM 2026",
          type: "text"
        },
        phone: {
          label: "Phone Number",
          value: "+91 98765 43220",
          type: "text"
        },
        document_1: {
          label: "Marksheet",
          value: "https://online.jaipuria.ac.in/uploads/arjun_marksheet.pdf",
          type: "file"
        },
        document_2: {
          label: "ID Proof",
          value: "https://online.jaipuria.ac.in/uploads/arjun_id.pdf",
          type: "file"
        },
        document_3: {
          label: "Photo",
          value: "https://online.jaipuria.ac.in/uploads/arjun_photo.jpg",
          type: "file"
        }
      }
    },
    {
      entry_id: 1012,
      form_id: 1234,
      date: "2025-11-11T16:40:00",
      status: "read",
      fields: {
        student_name: {
          label: "Student Name",
          value: "Divya Mehta",
          type: "text"
        },
        email: {
          label: "Email",
          value: "divya.mehta@student.jaipuria.ac.in",
          type: "email"
        },
        course: {
          label: "Course",
          value: "MBA 2025",
          type: "text"
        },
        phone: {
          label: "Phone Number",
          value: "+91 98765 43221",
          type: "text"
        },
        document_1: {
          label: "Marksheet",
          value: "https://online.jaipuria.ac.in/uploads/divya_marksheet.pdf",
          type: "file"
        }
      }
    }
  ],
  pagination: {
    page: 1,
    per_page: 20,
    total: 125
  }
};

// Filter and paginate mock data based on search params
export function getMockEntries(
  page: number = 1,
  perPage: number = 20,
  search: string = "",
  dateFrom?: string,
  dateTo?: string
): WPFormsEntriesResponse {
  let filtered = [...mockEntries.entries];

  // Apply search filter
  if (search) {
    const searchLower = search.toLowerCase();
    filtered = filtered.filter((entry) => {
      const studentName = entry.fields.student_name?.value?.toLowerCase() || "";
      const email = entry.fields.email?.value?.toLowerCase() || "";
      const course = entry.fields.course?.value?.toLowerCase() || "";
      return (
        studentName.includes(searchLower) ||
        email.includes(searchLower) ||
        course.includes(searchLower)
      );
    });
  }

  // Apply date filters
  if (dateFrom) {
    const fromDate = new Date(dateFrom);
    filtered = filtered.filter((entry) => new Date(entry.date) >= fromDate);
  }

  if (dateTo) {
    const toDate = new Date(dateTo);
    toDate.setHours(23, 59, 59, 999); // Include the entire day
    filtered = filtered.filter((entry) => new Date(entry.date) <= toDate);
  }

  // Calculate pagination
  const total = filtered.length;
  const startIndex = (page - 1) * perPage;
  const endIndex = startIndex + perPage;
  const paginatedEntries = filtered.slice(startIndex, endIndex);

  return {
    entries: paginatedEntries,
    pagination: {
      page,
      per_page: perPage,
      total,
    },
  };
}

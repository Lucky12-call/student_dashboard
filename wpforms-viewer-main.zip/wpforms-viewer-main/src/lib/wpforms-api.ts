import type { WPFormsEntriesResponse, FetchEntriesParams } from "@/types/wpforms";
import { getMockEntries } from "./mock-data";

// Configuration - update these with your actual values
const API_CONFIG = {
  BASE_URL: import.meta.env.VITE_WORDPRESS_BASE_URL || "https://online.jaipuria.ac.in/Lmslogin",
  FORM_ID: import.meta.env.VITE_WPFORMS_FORM_ID || "1234",
  // Add these if you need Basic Auth
  AUTH_USER: import.meta.env.VITE_WORDPRESS_AUTH_USER || "",
  AUTH_PASSWORD: import.meta.env.VITE_WORDPRESS_AUTH_PASSWORD || "",
  // Set to false to use real API, true to use mock data
  USE_MOCK_DATA: import.meta.env.VITE_USE_MOCK_DATA !== "false",
};

/**
 * Fetches WPForms entries from the WordPress REST API
 * 
 * @param params - Query parameters for filtering and pagination
 * @returns Promise with entries and pagination data
 */
export async function fetchWPFormsEntries(
  params: FetchEntriesParams
): Promise<WPFormsEntriesResponse> {
  const {
    formId = API_CONFIG.FORM_ID,
    page = 1,
    perPage = 20,
    search = "",
    dateFrom,
    dateTo,
  } = params;

  // Use mock data if enabled
  if (API_CONFIG.USE_MOCK_DATA) {
    // Simulate network delay for realistic feel
    await new Promise((resolve) => setTimeout(resolve, 500));
    return getMockEntries(page, perPage, search, dateFrom, dateTo);
  }

  // Build query string
  const queryParams = new URLSearchParams({
    form_id: formId,
    page: page.toString(),
    per_page: perPage.toString(),
  });

  if (search) {
    queryParams.append("search", search);
  }

  if (dateFrom) {
    queryParams.append("date_from", dateFrom);
  }

  if (dateTo) {
    queryParams.append("date_to", dateTo);
  }

  const url = `${API_CONFIG.BASE_URL}/wp-json/custom-wpforms/v1/entries?${queryParams.toString()}`;

  // Prepare headers
  const headers: HeadersInit = {
    "Content-Type": "application/json",
  };

  // Add Basic Auth if credentials are provided
  if (API_CONFIG.AUTH_USER && API_CONFIG.AUTH_PASSWORD) {
    const credentials = btoa(`${API_CONFIG.AUTH_USER}:${API_CONFIG.AUTH_PASSWORD}`);
    headers["Authorization"] = `Basic ${credentials}`;
  }

  try {
    const response = await fetch(url, {
      method: "GET",
      headers,
    });

    if (!response.ok) {
      throw new Error(
        `Failed to fetch entries: ${response.status} ${response.statusText}`
      );
    }

    const data: WPFormsEntriesResponse = await response.json();
    return data;
  } catch (error) {
    console.error("Error fetching WPForms entries:", error);
    throw error;
  }
}

/**
 * Get a single entry by ID
 * You can implement this if your WordPress endpoint supports it
 */
export async function fetchSingleEntry(entryId: number): Promise<any> {
  // Placeholder - implement based on your endpoint
  const url = `${API_CONFIG.BASE_URL}/wp-json/custom-wpforms/v1/entries/${entryId}`;
  
  const headers: HeadersInit = {
    "Content-Type": "application/json",
  };

  if (API_CONFIG.AUTH_USER && API_CONFIG.AUTH_PASSWORD) {
    const credentials = btoa(`${API_CONFIG.AUTH_USER}:${API_CONFIG.AUTH_PASSWORD}`);
    headers["Authorization"] = `Basic ${credentials}`;
  }

  const response = await fetch(url, { headers });
  
  if (!response.ok) {
    throw new Error(`Failed to fetch entry: ${response.status}`);
  }

  return response.json();
}
